<?php
use yii\helpers\Html;
use yii\jui\DatePicker;

?>
<?= Html::encode($message) ?>
</br>
<label>日期 </label>
<?= DatePicker::widget(['name' => 'date']) ?>
